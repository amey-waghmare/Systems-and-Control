%% Project LQG and Kalman Predictor State Augmentation
% Amey Samrat Waghmare
% 203230013

clear;
clc;

M = sum([2,0,3,2,3,0,0,1,3]);
fprintf("%d Is an Even Number\n",M)

SetGraphics;

% Load Nonlinear system
load System1_Parameters;
global sys;

% Simulation Time related parameters
Simulation_Time = 25;
Samp_T = 0.1;
Ns = Simulation_Time/Samp_T;
randn('seed',0);


% Dimensions of the Dynamic System
n_st = 3;
n_op = 2;
n_ip = 2;
n_d = 1;


Q_d = 0.015^2;
small_gamma_param = (2*1)/(3);
Q_b = small_gamma_param*[1^2 0; 0 0.5^2];
R = [0.2^2 0 ; 0 0.25^2];


% Initialize Empty Matrices (*,Ns) for NONLINEAR MODEL
Xk = zeros(n_st,Ns);
Uk = zeros(n_ip,Ns);
Dk = zeros(n_d,Ns);
Yk = zeros(n_op,Ns);

% Purturbation profiles
uk = zeros(n_ip,Ns);
yk = zeros(n_op,Ns);

% Load Linearized Model and Discretize it
load System1_ContLinmod
sys.phy = expm(A_mat * Samp_T);
sys.gamma_u = (sys.phy - eye(n_st) ) * inv(A_mat) * B_mat;
sys.gamma_d = (sys.phy - eye(n_st) ) * inv(A_mat) * H_mat;
sys.C_mat = C_mat;


W_x = diag([5000,1,1]);
W_u = ((2+0+2+0+0)/(3+3+1+3))*diag([5,1]);

[G_mat, S_inf, E_v] = dlqr(sys.phy, sys.gamma_u, W_x,W_u);

poles_G_mat = eig(sys.phy - sys.gamma_u * G_mat);
%fprintf("Closed loop poles of controller are \n")
%poles_G_mat    %#ok

% Observer Design for state augmentation
% State Augmentation
phy_aug = [sys.phy sys.gamma_u; zeros(n_ip,n_st) eye(n_ip)];
gamma_u_aug = [sys.gamma_u; zeros(n_ip,n_ip)];
%gamma_d_aug = [sys.gamma_d zeros(n_st,n_ip); zeros(n_ip,n_d) eye(n_ip)];
gamma_d_aug = blkdiag(sys.gamma_d,eye(n_ip));
C_aug = [sys.C_mat zeros(n_op,n_ip)];
D_aug = zeros(n_op,n_ip+n_d+n_ip);

Q_a = blkdiag(Q_d,Q_b);
N_a = zeros(n_d + n_ip , n_op);
R_a = R;

dmod = ss(phy_aug, [gamma_u_aug, gamma_d_aug], C_aug, D_aug, Samp_T);
[KEST, L_a, P_a_inf] = kalman(dmod, Q_a, R_a, N_a);



%State Augmentation
beta_hat = zeros(n_ip,Ns);

us = zeros(n_ip,Ns);
xs = zeros(n_st,Ns);
% Observer Profile
xhat_k = zeros(n_st,Ns);
Xhat = zeros(n_st,Ns);

% Controller Profiles
Rk = zeros(n_op,Ns);
rk = zeros(n_op,Ns);
ek = zeros(n_op,Ns);


% Input Constraints
Uk_Hi = [250 60]';
Uk_Lo = [0 0]';
uk_H = Uk_Hi - sys.Us;
uk_L = Uk_Lo - sys.Us;


% Initial Conditions
Xk(:,1) = sys.Xs ;
Yk(:,1) = sys.Ys;
xhat_k(:,1) = [0 0 0]';
Xhat(:,1) = sys.Xs;

Ku = sys.C_mat*(inv(eye(n_st) - sys.phy))*sys.gamma_u;
Kbeta = sys.C_mat*(inv(eye(n_st) - sys.phy))* sys.gamma_u;


kT = zeros(1,Ns);        % Time Array


for k = 1:Ns-1
    
    kT(k) = (k-1)*Samp_T;
    
    
    if (k < (6/Samp_T)) && (k >= (12/Samp_T))
        rk(:,k) = [0 0]';
    elseif (k >= (6/Samp_T)) && (k< (12/Samp_T))
        rk(:,k) = [-5 0]';
    end
        
    if (k < (18/Samp_T))
        dk = 0 + (randn * 0.015);
    elseif (k >= (18/Samp_T))
        dk = 0.1 + (randn * 0.015);
    end
    
    
    Rk(:,k) = sys.Ys + rk(:,k);
    Dk(k) = sys.Ds + dk ;
    
    us(:,k) = inv(Ku) * (rk(:,k) - (Kbeta)*beta_hat(:,k) );
    xs(:,k) = inv(eye(n_st) - sys.phy) * (  sys.gamma_u*inv(Ku)*rk(:,k)   );
    uk(:,k) = us(:,k) - G_mat*( xhat_k(:,k) - xs(:,k) );
    
    % Input Constraints
    if (uk(1,k) <= uk_L(1))
        uk(1,k) = uk_L(1);
    elseif (uk(1,k) >= uk_H(1))
        uk(1,k) = uk_H(1);
    end
    if (uk(2,k) <= uk_L(2))
        uk(2,k) = uk_L(2);
    elseif (uk(2,k) >= uk_H(2))
        uk(2,k) = uk_H(2);
    end
    
    Uk(:,k) = uk(:,k) + sys.Us;
    sys.Uk = Uk(:,k);
    sys.Dk = Dk(k);
    [T,Xt] = ode45('System1_Dynamics', [0 Samp_T], Xk(:,k));       % RK solver
    Xk(:,k+1) = Xt(end,:)';
    Yk(:,k+1) = sys.C_mat*Xk(:,k+1) + mvnrnd(zeros(n_op,1),R)';
    
    yk(:,k) = Yk(:,k) - sys.Ys;
    ek(:,k) = yk(:,k) - C_aug * [xhat_k(:,k); beta_hat(:,k)];
    
    temp = phy_aug*[xhat_k(:,k); beta_hat(:,k)] + gamma_u_aug*uk(:,k) + L_a*ek(:,k);
    xhat_k(:,k+1) = temp(1:n_st);
    beta_hat(:,k+1) = temp(n_st+1:end);
    Xhat(:,k+1) = xhat_k(:,k+1) + sys.Xs;
    
end

% At final Time Instant
kT(Ns) = Ns*Samp_T;
Uk(:,Ns) = Uk(:,Ns-1);
Dk(Ns) = Dk(Ns-1);
Rk(:,Ns) = Rk(:,Ns-1);

us(:,Ns) = us(:,Ns-1);
xs(:,Ns) = xs(:,Ns-1);


figure(1)   % For Myself
subplot(3,1,1),plot(kT,Xk(1,:),'b-'),grid,ylabel("X1"),title('State Variables')
subplot(3,1,2),plot(kT,Xk(2,:),'b-'),grid,ylabel("X2")
subplot(3,1,3),plot(kT,Xk(3,:),'b-'),grid,ylabel("X3"),xlabel("Time (Min)")

figure(2)   % Asked result 1
subplot(2,1,1),plot(kT,Yk(1,:),'-',kT,Rk(1,:),'-r'),grid,ylabel('Y1'),title('Measured Outputs for Servo Control'),legend('Y1','R1')
subplot(2,1,2),plot(kT,Yk(2,:),'-',kT,Rk(2,:),'-r'),grid,ylabel('Y2'),xlabel('Time (Min)'),legend('Y2','R2')

figure(3)   % Asked Result 2 and 3
subplot(3,1,1),stairs(kT,Uk(1,:),'-','LineWidth',2),grid,ylabel('U1'),title('Manupulated Inputs')
subplot(3,1,2),stairs(kT,Uk(2,:),'-','LineWidth',2),grid,ylabel('U2')
subplot(3,1,3),stairs(kT,Dk,'-','LineWidth',2),grid,ylabel('D'),xlabel('Time (Min)')

LQOC.kT = kT;
LQOC.Yk = Yk;
LQOC.Rk = Rk;
LQOC.Uk = Uk;
LQOC.Dk = Dk;

save LQOC LQOC