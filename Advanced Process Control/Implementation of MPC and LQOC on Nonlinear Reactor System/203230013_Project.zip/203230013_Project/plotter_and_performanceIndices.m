%% Project: Plots and Performance Indices
% Amey Samrat Waghmare
% 203230013

clear;
clc;

SetGraphics;

load System1_Parameters

load PIController
load PolePlacement
load LQOC
load MPC

figure(1)  % Asked result 1
subplot(2,1,1),plot(LQOC.kT,PI.Rk(1,:),'-k',LQOC.kT,PI.Yk(1,:),'-r',LQOC.kT,PolePlacement.Yk(1,:),'-b',LQOC.kT,LQOC.Yk(1,:),'-g',LQOC.kT,MPC.Yk(1,:),'-y'),grid,ylabel('Y1'),title('Measured Outputs'),legend('R','PI','PoleP','LQOC','MPC')
subplot(2,1,2),plot(LQOC.kT,PI.Rk(2,:),'-k',LQOC.kT,PI.Yk(2,:),'-r',LQOC.kT,PolePlacement.Yk(2,:),'-b',LQOC.kT,LQOC.Yk(2,:),'-g',LQOC.kT,MPC.Yk(2,:),'-y'),grid,ylabel('Y2'),xlabel('Time (Min)'),legend('R','PI','PoleP','LQOC','MPC')

stairs_plots_kT = [LQOC.kT, LQOC.kT];
stairs_plots_U1 = [PI.Uk(1,:); PolePlacement.Uk(1,:); LQOC.Uk(1,:); MPC.Uk(1,:)]';
stairs_plots_U2 = [PI.Uk(2,:); PolePlacement.Uk(2,:); LQOC.Uk(2,:); MPC.Uk(2,:)]';

line_colour = ['r' 'b' 'g' 'y'];
str = ["PI","PoleP","LQOC","MPC"];
figure(2)  % Asked result 2 and 3
for k = 1:length(line_colour)
    hold on
    subplot(3,1,1),stairs(LQOC.kT,stairs_plots_U1(:,k),'Color',line_colour(k),'LineWidth',2),ylabel("U_{1}"),legend(str)%,'U_{1}PoleP','U_{1}LQOC','U_{1}MPC')
    grid on
end

for k = 1:length(line_colour)
    hold on
    subplot(3,1,2),stairs(LQOC.kT,stairs_plots_U2(:,k),'Color',line_colour(k),'LineWidth',2,'LineWidth',2),grid,ylabel("U_{2}"),legend(str)
    grid on
end
subplot(3,1,3),stairs(LQOC.kT,PI.Dk,'-b','LineWidth',2),grid,ylabel('D'),xlabel('Time (Min)')




% SSE Calculation

SSE_PI = sum((PI.Rk - PI.Yk).^2,2)
SSE_PolePlacement = sum((PolePlacement.Rk - PolePlacement.Yk).^2,2)
SSE_LQOC = sum((LQOC.Rk - LQOC.Yk).^2,2)
SSE_MPC = sum((MPC.Rk - MPC.Yk).^2,2)

% SSMV Calculation

SSMV_PI = sum((PI.Uk - sys.Us).^2,2)
SSMV_PolePlacement = sum((PolePlacement.Uk - sys.Us).^2,2)
SSMV_LQOC = sum((LQOC.Uk - sys.Us).^2,2)
SSMV_MPC = sum((MPC.Uk - sys.Us).^2,2)



