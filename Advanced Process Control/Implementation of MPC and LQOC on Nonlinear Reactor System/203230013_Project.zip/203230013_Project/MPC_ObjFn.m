function obj_fn = MPC_ObjFn(Uf_vec)

global N_pred N_con W_x W_u Wdu W_inf n_st n_ip
global x_temp beta_temp xs_temp us_temp uk_minus_1
global sys

zk_pred = zeros(n_st, N_pred);
zk_pred(:,1) = x_temp;
ukf = zeros(n_ip, N_pred);
n2 = 0;

for k = 1:N_pred
    if (k<=N_con)
        n1 = n2 + 1;
        n2 = k * n_ip;
        ukf(:,k) = Uf_vec(n1:n2,1)';
    else
        ukf(:,k) = Uf_vec(n1:n2,1)';
    end
end

del_uk = ukf(:,1) - uk_minus_1;
err = zk_pred(:,1) - xs_temp;
d_uk = ukf(:,1) - us_temp;
obj_fn = (err' * W_x * err) + (d_uk' * W_u * d_uk) + (del_uk' * Wdu * del_uk);

for k = 2:N_pred
    zk_pred(:,k) = sys.phy * zk_pred(:,k-1) + sys.gamma_u * (ukf(:,k-1) + beta_temp);
    err = zk_pred(:,k) - xs_temp;
    del_uk = ukf(:,k) - ukf(:,k-1);
    d_uk = ukf(:,k) - us_temp;
    if (k<N_pred)
        obj_fn = obj_fn + ((err' * W_x * err) + (d_uk' * W_u * d_uk) + (del_uk' * Wdu * del_uk));
    else   % Final instant 
        obj_fn = obj_fn + (err' * W_inf * err);
    end



end

