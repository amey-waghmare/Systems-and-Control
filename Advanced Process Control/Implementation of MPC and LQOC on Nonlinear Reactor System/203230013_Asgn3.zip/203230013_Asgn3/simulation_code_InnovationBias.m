%% Assignment 3 Innovation Bias
% Amey Samrat Waghmare
% 203230013

clear;
clc;

M = sum([2,0,3,2,3,0,0,1,3]);
fprintf("%d Is an Even Number\n",M)

SetGraphics;

% Load Nonlinear system
load System1_Parameters;
global sys;

% Simulation Time related parameters
Simulation_Time = 25;
Samp_T = 0.1;
Ns = Simulation_Time/Samp_T;
randn('seed',0);

% Dimensions of the Dynamic System
n_st = 3;
n_op = 2;
n_ip = 2;
n_d = 1;

% Initialize Empty Matrices (*,Ns) for NONLINEAR MODEL
Xk = zeros(n_st,Ns);
Uk = zeros(n_ip,Ns);
Dk = zeros(n_d,Ns);
Yk = zeros(n_op,Ns);

% Purturbation profiles
uk = zeros(n_ip,Ns);
yk = zeros(n_op,Ns);

% Load Linearized Model and Discretize it
load System1_ContLinmod
sys.phy = expm(A_mat * Samp_T);
sys.gamma_u = (sys.phy - eye(n_st) ) * inv(A_mat) * B_mat;
sys.gamma_d = (sys.phy - eye(n_st) ) * inv(A_mat) * H_mat;
sys.C_mat = C_mat;

% Controller Design (Pole Placement)
ctrb_mat = ctrb(sys.phy,sys.gamma_u);
n_ctrb = rank(ctrb_mat);
fprintf("\n The rank of Controllability matrix is %d \n", n_ctrb)
cl_poles = [0.7 0.4 0.2]';
G_mat = place( sys.phy,sys.gamma_u,cl_poles );
poles_G_mat = eig(sys.phy - sys.gamma_u * G_mat);
fprintf("Closed loop poles of controller are \n")
poles_G_mat    %#ok

% Observer Design
obsv_mat = obsv(sys.phy,sys.C_mat);
n_obsv = rank(obsv_mat);
fprintf("\n The rank of Observability matrix is %d \n", n_obsv)
cl_poles_obsv = [0.3 0.4 0.5]';
L_mat = place( sys.phy',sys.C_mat',cl_poles_obsv )';
poles_L_mat = eig(sys.phy - L_mat * sys.C_mat);
fprintf("Closed loop poles of observer are \n")
poles_L_mat    %#ok


us = zeros(n_ip,Ns);
xs = zeros(n_st,Ns);
% Observer Profile
xhat_k = zeros(n_st,Ns);
Xhat = zeros(n_st,Ns);

% Controller Profiles
Rk = zeros(n_op,Ns);
rk = zeros(n_op,Ns);
ek = zeros(n_op,Ns);
efk = zeros(n_op,Ns);

% Innovation filter (in matrix form)
phy_e = 0.8*eye(n_op);

% Input Constraints
Uk_Hi = [250 60]';
Uk_Lo = [0 0]';
uk_H = Uk_Hi - sys.Us;
uk_L = Uk_Lo - sys.Us;


% Initial Conditions
Xk(:,1) = sys.Xs + [0.005 2 -2]';
Yk(:,1) = sys.Ys;
xhat_k(:,1) = [0 0 0]';
Xhat(:,1) = sys.Xs + [0 0 0]';

Ku = sys.C_mat*(inv(eye(n_st) - sys.phy))*sys.gamma_u;
Kbeta = sys.C_mat*(inv(eye(n_st) - sys.phy))* L_mat;


kT = zeros(1,Ns);        % Time Array


for k = 1:Ns-1
    
    kT(k) = (k-1)*Samp_T;
    
    
    if (k < (6/Samp_T)) && (k >= (12/Samp_T))
        rk(:,k) = [0 0]';
    elseif (k >= (6/Samp_T)) && (k< (12/Samp_T))
        rk(:,k) = [-5 0]';
    end
        
    if (k < (18/Samp_T))
        dk = 0;
    elseif (k >= (18/Samp_T))
        dk = 0.1;
    end
    
    
    Rk(:,k) = sys.Ys + rk(:,k);
    Dk(k) = sys.Ds + dk;
    
    % Inputs at kth instant
    yk(:,k) = Yk(:,k) - sys.Ys;
    ek(:,k) = yk(:,k) - sys.C_mat*xhat_k(:,k);
    
    if (k>1)
        efk(:,k) = (phy_e*efk(:,k-1)) + (eye(n_op) - phy_e)*ek(:,k);
    end
    
    us(:,k) = inv(Ku) * (rk(:,k) - (Kbeta+eye(n_op))*efk(:,k) );
    xs(:,k) = inv(eye(n_st) - sys.phy) * (  sys.gamma_u*us(:,k) + L_mat*efk(:,k)  );
    uk(:,k) = us(:,k) - G_mat*( xhat_k(:,k) - xs(:,k) );
    
    % Input Constraints
    if (uk(1,k) <= uk_L(1))
        uk(1,k) = uk_L(1);
    elseif (uk(1,k) >= uk_H(1))
        uk(1,k) = uk_H(1);
    end
    if (uk(2,k) <= uk_L(2))
        uk(2,k) = uk_L(2);
    elseif (uk(2,k) >= uk_H(2))
        uk(2,k) = uk_H(2);
    end
    
    Uk(:,k) = uk(:,k) + sys.Us;
    sys.Uk = Uk(:,k);
    sys.Dk = Dk(k);
    [T,Xt] = ode45('System1_Dynamics', [0 Samp_T], Xk(:,k));       % RK solver
    Xk(:,k+1) = Xt(end,:)';
    Yk(:,k+1) = sys.C_mat*Xk(:,k+1);
    
    
    xhat_k(:,k+1) = sys.phy*xhat_k(:,k) + sys.gamma_u*uk(:,k) + L_mat*ek(:,k);
    Xhat(:,k+1) = xhat_k(:,k+1) + sys.Xs;
    
end

% At final Time Instant
kT(Ns) = Ns*Samp_T;
Uk(:,Ns) = Uk(:,Ns-1);
Dk(Ns) = Dk(Ns-1);
Rk(:,Ns) = Rk(:,Ns-1);
efk(:,Ns) = efk(:,Ns-1);
us(:,Ns) = us(:,Ns-1);
xs(:,Ns) = xs(:,Ns-1);


figure(1)
subplot(3,1,1),plot(kT,Xk(1,:),'b-'),grid,ylabel("X1"),title('State Variables')
subplot(3,1,2),plot(kT,Xk(2,:),'b-'),grid,ylabel("X2")
subplot(3,1,3),plot(kT,Xk(3,:),'b-'),grid,ylabel("X3"),xlabel("Time (Min)")

figure(2)
subplot(2,1,1),plot(kT,Yk(1,:),'-',kT,Rk(1,:),'-r'),grid,ylabel('Y1'),title('Measured Outputs for Servo Control'),legend('Y1','R1')
subplot(2,1,2),plot(kT,Yk(2,:),'-',kT,Rk(2,:),'-r'),grid,ylabel('Y2'),xlabel('Time (Min)'),legend('Y2','R2')

figure(3)
subplot(3,1,1),stairs(kT,Uk(1,:),'-','LineWidth',2),grid,ylabel('U1'),title('Manupulated Inputs')
subplot(3,1,2),stairs(kT,Uk(2,:),'-','LineWidth',2),grid,ylabel('U2')
subplot(3,1,3),stairs(kT,Dk,'-','LineWidth',2),grid,ylabel('D'),xlabel('Time (Min)')

figure(4)
subplot(2,1,1),plot(kT,efk(1,:),'r-'),grid,ylabel("ef1"),title("Filtered Innovation")
subplot(2,1,2),plot(kT,efk(2,:),'r-'),grid,ylabel("ef2")

figure(5)
subplot(3,1,1),plot(kT,Xhat(1,:)-Xk(1,:),'b-'),grid,ylabel("X1"),title('State Estimation Errors')
subplot(3,1,2),plot(kT,Xhat(2,:)-Xk(2,:),'b-'),grid,ylabel("X2")
subplot(3,1,3),plot(kT,Xhat(3,:)-Xk(3,:),'b-'),grid,ylabel("X3"),xlabel("Time (Min)")

figure(6)
subplot(3,1,1),plot(kT,xs(1,:),'b-'),grid,ylabel("Xs1"),title('Target model Steady state')
subplot(3,1,2),plot(kT,xs(2,:),'b-'),grid,ylabel("Xs2")
subplot(3,1,3),plot(kT,xs(3,:),'b-'),grid,ylabel("Xs3"),xlabel("Time (Min)")

figure(7)
subplot(2,1,1),stairs(kT,us(1,:),'-','LineWidth',2),grid,ylabel('Us1'),title('Target model Inputs')
subplot(2,1,2),stairs(kT,us(2,:),'-','LineWidth',2),grid,ylabel('Us2')