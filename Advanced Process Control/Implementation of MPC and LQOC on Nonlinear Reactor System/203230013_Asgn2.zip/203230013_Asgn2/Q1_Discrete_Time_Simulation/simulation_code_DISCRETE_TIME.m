%% Assignment 2
% Amey Samrat Waghmare
% 203230013

clear;
clc;

SetGraphics;

% Load Nonlinear system
load System1_Parameters;
global sys;

% Simulation Time related parameters
Simulation_Time = 50;
Samp_T = 0.1;
Ns = Simulation_Time/Samp_T;
randn('seed',0);

% Dimensions of the Dynamic System
n_st = 3;
n_op = 2;
n_ip = 2;
n_d = 1;

% Initialize Empty Matrices (*,Ns) for NONLINEAR MODEL
Xk = zeros(n_st,Ns);
Uk = zeros(n_ip,Ns);
Dk = zeros(n_d,Ns);
Yk = zeros(n_op,Ns);

% Load Linearized Model and Discretize it
load System1_ContLinmod
sys.phy = expm(A_mat * Samp_T);
sys.gamma_u = (sys.phy - eye(n_st) ) * inv(A_mat) * B_mat;
sys.gamma_d = (sys.phy - eye(n_st) ) * inv(A_mat) * H_mat;

% Initialize Empty Matrices (*,Ns) for LINEARIZED MODEL
xkl = zeros(n_st,Ns);
XkL = zeros(n_st,Ns);
YkL = zeros(n_op,Ns);

% Inputs 
N_RBS = [25 30]';                 % Period of RBS
uk_ampl = [10 4]';                % Amplitude of RBS around corresponding Us
R_mat = diag(sys.meas_sigma.^2);  % Measurement noise Covariance

% %Initial Conditions
% Nonlinear Model
Xk(:,1) = sys.Xs;
Yk(:,1) = sys.C_mat * Xk(:,1);
% Linearized Model

XkL(:,1) = sys.Xs;
YkL(:,1) = sys.C_mat * XkL(:,1);

kT = zeros(1,Ns);                  % Time Array
deluk = zeros(n_ip,1);             % Corresponding to Uk
vk = zeros(n_op,1);                % Corresponding to Dk Gaussian(0,R_mat)


for k = 1:Ns-1
    kT(k) = (k-1)*Samp_T;          % Actual Time
  
    % For Random Input Signal, around Us and + or - by uk_ampl (randn ly)
    for i = 1:n_ip
        if (rem(k,N_RBS(i)) == 0)
           deluk(i) = uk_ampl(i)*sign(randn);
        end
    end
    
    Uk(:,k) = sys.Us + deluk;
    dk = sys.dk_sigma*randn;
    Dk(k) = sys.Ds + dk;
    
    
    % Simulation for Nonlinear System
    sys.Uk = Uk(:,k);
    sys.Dk = Dk(k);
    [T,Xt] = ode45('System1_Dynamics', [0 Samp_T], Xk(:,k));       % RK solver
    Xk(:,k+1) = Xt(end,:)';
    vk = (mvnrnd(zeros(n_op,1),R_mat,1))'; % Measurement Noise %% Keep this to keep RBS same as Assignment 1 (due to seed 0 and mvrnd)
    Yk(:,k+1) = sys.C_mat*Xk(:,k+1) ;%+ vk;
    
    % Simulation for Discrete Linearized System
    xkl(:,k+1) = (sys.phy * xkl(:,k)) + (sys.gamma_u * deluk) + (sys.gamma_d * dk);
    XkL(:,k+1) = xkl(:,k+1) + sys.Xs;
    YkL(:,k+1) = sys.Ys + sys.C_mat * xkl(:,k+1) ;%+ vk;
    
end

% At final Time Instant
kT(Ns) = Ns*Samp_T;
Uk(:,Ns) = sys.Us + deluk;
dk = sys.dk_sigma * randn;
Dk(Ns) = sys.Ds + dk;

% Figures subplot(m,n,p) Grid(m,n) and pth loc

figure(1)
subplot(3,1,1),plot(kT,Xk(1,:),'b-'),grid,ylabel("X1"),title('State Variables of Nonlinear Model')
subplot(3,1,2),plot(kT,Xk(2,:),'b-'),grid,ylabel("X2")
subplot(3,1,3),plot(kT,Xk(3,:),'b-'),grid,ylabel("X3"),xlabel("Time (Min)")

figure(2)
subplot(3,1,1),plot(kT,Xk(1,:) - XkL(1,:),'b-'),grid,ylabel("X1"),title('Difference between Linear and Nonlinear model')
subplot(3,1,2),plot(kT,Xk(2,:) - XkL(2,:),'b-'),grid,ylabel("X2")
subplot(3,1,3),plot(kT,Xk(3,:) - XkL(3,:),'b-'),grid,ylabel("X3"),xlabel("Time (Min)")

figure(3)
subplot(3,1,1),stairs(kT,Uk(1,:),'-','LineWidth',2),grid,ylabel('U1'),title('Manupulated Inputs')
subplot(3,1,2),stairs(kT,Uk(2,:),'-','LineWidth',2),grid,ylabel('U2')
subplot(3,1,3),stairs(kT,Dk,'-','LineWidth',2),grid,ylabel('D'),xlabel('Time (Min)')

% Extra plots
figure(4)
subplot(3,1,1),plot(kT,XkL(1,:),'b-'),grid,ylabel("X1"),title('State Variables (Linearized Discretized System)')
subplot(3,1,2),plot(kT,XkL(2,:),'b-'),grid,ylabel("X2")
subplot(3,1,3),plot(kT,XkL(3,:),'b-'),grid,ylabel("X3"),xlabel("Time (Min)")

figure(5)
subplot(2,2,1),plot(kT,Yk(1,:),'b-'),grid,ylabel('Y1'),title('Measured Outputs of Nonlinear and Linearized Discretized System')
subplot(2,2,3),plot(kT,Yk(2,:),'b-'),grid,ylabel('Y2'),xlabel('Time (Min)')
subplot(2,2,2),plot(kT,YkL(1,:),'-'),grid,ylabel('Y1')
subplot(2,2,4),plot(kT,YkL(2,:),'-'),grid,ylabel('Y2'),xlabel('Time (Min)')

disp("The Obtained response shows very small error between the State variables of the Actual Nonlinear system ")
disp("and the Linearized Discretized System.")