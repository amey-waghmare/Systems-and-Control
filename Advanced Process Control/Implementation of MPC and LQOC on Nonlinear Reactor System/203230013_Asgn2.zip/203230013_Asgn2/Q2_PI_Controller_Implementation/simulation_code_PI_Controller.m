%% Assignment 2 PI Implementation
% Amey Samrat Waghmare
% 203230013


% Kind of control to be specified at line 59

clear;
clc;

SetGraphics;

% Load Nonlinear system
load System1_Parameters;
global sys;

% Simulation Time related parameters
Simulation_Time = 10;
Samp_T = 0.1;
Ns = Simulation_Time/Samp_T;
randn('seed',0);

% Dimensions of the Dynamic System
n_st = 3;
n_op = 2;
n_ip = 2;
n_d = 1;

% Initialize Empty Matrices (*,Ns) for NONLINEAR MODEL
Xk = zeros(n_st,Ns);
Uk = zeros(n_ip,Ns);
Dk = zeros(n_d,Ns);
Yk = zeros(n_op,Ns);

% Purturbation profiles
uk = zeros(n_ip,Ns);
yk = zeros(n_op,Ns);

% Controller Profiles
Eta = zeros(n_op,Ns);
Rk = zeros(n_op,Ns);
rk = zeros(n_op,Ns);
ek = zeros(n_op,Ns);

% PI Controller Parameters
Kc = [8.5396 -1.5703];
tauI = [0.7278 0.5286];
C_mat_PI = [Kc(1)/tauI(1) 0; 0 Kc(2)/tauI(2)];
D_mat_PI = [Kc(1) 0; 0 Kc(2)];

% Input Constraints
Uk_Hi = [250 60]';
Uk_Lo = [0 0]';
uk_H = Uk_Hi - sys.Us;
uk_L = Uk_Lo - sys.Us;

% What kind of problem? 1- Tracking, 0-Regulation
%#%#% Mention Here %%#%#
Servo_Problem = 1;
%-----------------#


% Initial Conditions
Xk(:,1) = sys.Xs;
Yk(:,1) = sys.C_mat * Xk(:,1);

kT = zeros(1,Ns);        % Time Array


for k = 1:Ns-1
    
    kT(k) = (k-1)*Samp_T;
    
    if (Servo_Problem == 1)
        if (k >= 5)           % Equivalent to t>= 0.5 min
            rk(:,k) = [-5 0]';
        else
            rk(:,k) = [0 0]';
        end
        dk = 0;
    elseif (Servo_Problem == 0)
        rk(:,k) = zeros(n_op,1);
        if (k >= 5)
            dk = 0.1;
        else
            dk = 0;
        end
    end
    Rk(:,k) = sys.Ys + rk(:,k);
    Dk(k) = sys.Ds + dk;
    
    % Inputs at kth instant
    yk(:,k) = Yk(:,k) - sys.Ys;
    ek(:,k) = rk(:,k) - yk(:,k);  % Controller error
    Eta(:,k+1) = Eta(:,k) + (ek(:,k)*Samp_T);  %Integral Error
    uk(:,k) = ( C_mat_PI * Eta(:,k) ) + ( D_mat_PI * ek(:,k) );
    
    % Input Constraints
    if (uk(1,k) <= uk_L(1))
        uk(1,k) = uk_L(1);
    elseif (uk(1,k) >= uk_H(1))
        uk(1,k) = uk_H(1);
    end
    if (uk(2,k) <= uk_L(2))
        uk(2,k) = uk_L(2);
    elseif (uk(2,k) >= uk_H(2))
        uk(2,k) = uk_H(2);
    end
    
    Uk(:,k) = uk(:,k) + sys.Us;
    sys.Uk = Uk(:,k);
    sys.Dk = Dk(k);
    [T,Xt] = ode45('System1_Dynamics', [0 Samp_T], Xk(:,k));       % RK solver
    Xk(:,k+1) = Xt(end,:)';
    Yk(:,k+1) = sys.C_mat*Xk(:,k+1);
    
end

% At final Time Instant
kT(Ns) = Ns*Samp_T;
Uk(:,Ns) = Uk(:,Ns-1);
Dk(Ns) = Dk(Ns-1);
Rk(:,Ns) = Rk(:,Ns-1);

figure(1)
subplot(3,1,1),plot(kT,Xk(1,:),'b-'),grid,ylabel("X1"),title('State Variables')
subplot(3,1,2),plot(kT,Xk(2,:),'b-'),grid,ylabel("X2")
subplot(3,1,3),plot(kT,Xk(3,:),'b-'),grid,ylabel("X3"),xlabel("Time (Min)")

if (Servo_Problem == 1)
    figure(2)
    subplot(2,1,1),plot(kT,Yk(1,:),'-',kT,Rk(1,:),'-r'),grid,ylabel('Y1'),title('Measured Outputs for Servo Control'),legend('Y1','R1')
    subplot(2,1,2),plot(kT,Yk(2,:),'-',kT,Rk(2,:),'-r'),grid,ylabel('Y2'),xlabel('Time (Min)'),legend('Y2','R2')

elseif (Servo_Problem == 0)
    figure(2)
    subplot(2,1,1),plot(kT,Yk(1,:),'-',kT,Rk(1,:),'-r'),grid,ylabel('Y1'),title('Measured Outputs for Regulatory Control'),,legend('Y1','R1')
    subplot(2,1,2),plot(kT,Yk(2,:),'-',kT,Rk(2,:),'-r'),grid,ylabel('Y2'),xlabel('Time (Min)'),legend('Y2','R2')
end

figure(3)
subplot(3,1,1),stairs(kT,Uk(1,:),'-','LineWidth',2),grid,ylabel('U1'),title('Manupulated Inputs')
subplot(3,1,2),stairs(kT,Uk(2,:),'-','LineWidth',2),grid,ylabel('U2')
subplot(3,1,3),stairs(kT,Dk,'-','LineWidth',2),grid,ylabel('D'),xlabel('Time (Min)')

disp("To change from Servo Control to Regulatory Control, change variable at line 59.")